﻿using oneXerpQB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InvoiceAdd
{
    public class CustomUtility
    {
        // TODO: Figure out when POs should be received and implement that logic here
        public static bool CheckIfPOShouldBeReceived(PurchaseOrder purchaseOrder)
        {
            return true;
        }
    }
}
